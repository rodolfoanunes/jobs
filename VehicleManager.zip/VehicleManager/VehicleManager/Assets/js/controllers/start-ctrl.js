'use strict';

webApp.controller('StartCtrl', ['$scope', '$rootScope', function ($scope, $rootScope) {
    $rootScope.setCurrentPage('', '', '');
}]);
