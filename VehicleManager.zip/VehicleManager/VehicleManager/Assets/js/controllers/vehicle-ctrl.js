'use strict';

webApp.controller('SearchVehicleCtrl', ['$scope', 'alertsManager', '$rootScope', 'vmServices', 'NgTableParams', function ($scope, alertsManager, $rootScope, vmServices, NgTableParams) {
    $rootScope.setCurrentPage('Veículos', 'vehicles/search', 'Pesquisa');
    $scope.vehiclesList = [];

    $scope.tableVehicles = new NgTableParams({}, {
        dataset: $scope.vehiclesList
    });

    $scope.init = function () {
        $scope.searchVehicles();
    }

    $scope.searchVehicles = function () {
        vmServices.get('vehiclesController/vehicles', function (data) {
            if (data.length == 0) {
                alertsManager.addInfo('Nenhum veículo encontrado!');
                return;
            }

            $scope.vehiclesList = data;

            $scope.tableVehicles = new NgTableParams({}, {
                dataset: $scope.vehiclesList,
            });
        });
    }

    $scope.delete = function (id) {
        vmServices.delete('vehiclesController/vehicle/' + id + '/delete', function (data) {
            alertsManager.addSuccess('Veículo excluído com sucesso!');
            $scope.searchVehicles();
        });
    }
}]);
webApp.controller('RegisterVehicleCtrl', ['$scope', 'alertsManager', '$rootScope', 'vmServices', '$stateParams', function ($scope, alertsManager, $rootScope, vmServices, $stateParams) {
    $scope.action = $stateParams.id == '0' ? 'Inserir' : 'Editar';
    $rootScope.setCurrentPage('Veículos', 'vehicles/search', $scope.action);
    $scope.vehicle = {};

    $scope.init = function () {
        if ($stateParams.id > 0)
            $scope.searchVehicle();
    }

    $scope.searchVehicle = function () {
        vmServices.get('vehiclesController/vehicle/' + $stateParams.id, function (data) {
            $scope.vehicle = $rootScope.parseFieldsToString(data, 'IsNew');
        });
    }

    $scope.save = function () {
        if ($rootScope.isValidForm($scope.editForm)) {
            if ($stateParams.id == '0') {
                vmServices.post('vehiclesController/vehicle/insert', $scope.vehicle, function (data) {
                    alertsManager.addSuccess('Veículo inserido com sucesso!')
                    $scope.return();
                });
            } else {
                vmServices.put('vehiclesController/vehicle/update', $scope.vehicle, function (data) {
                    alertsManager.addSuccess('Veículo editado com sucesso!');
                    $scope.return();
                });
            }
        }
    }

    $scope.return = function () {
        window.location.href = '#/vehicles/search';
    }
}]);
