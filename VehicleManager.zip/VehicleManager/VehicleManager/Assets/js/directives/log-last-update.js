webApp.directive('logLastUpdate', function () {
    return {
        restrict: 'A',
        templateUrl: 'Assets/views/directives/directiveLogLastUpdate.html',
        replace: true,
        scope: {
            object: '='
        },
        controller: function ($scope, alertsManager) {
            $scope.popoverTemplate = 'logLastUpdateTemplate.html';
            $scope.hasValue = false;

            $scope.$watch('object', function (newVal) {
                if (!$.isEmptyObject(newVal)) {
                    var hasDateCreation = $scope.object.DateCreation != undefined && $scope.object.DateCreation != null && $scope.object.DateCreation != '',
                        hasDateUpdate = $scope.object.DateUpdate != undefined && $scope.object.DateUpdate != null && $scope.object.DateUpdate != '';

                    if (hasDateCreation) {
                        $scope.hasValue = true;
                        $scope.dsDateCreation = '<b>Data:</b> {{object.DateCreation | date:\'dd/MM/yyyy\'}} às {{object.DateCreation | date:\'HH:mm:ss\'}}h';

                        if (hasDateUpdate)
                            $scope.dsDateUpdate = '<b>Data:</b> {{object.DateUpdate | date:\'dd/MM/yyyy\'}} às {{object.DateUpdate | date:\'HH:mm:ss\'}}h';
                    }
                }
            });
        }
    };
});
