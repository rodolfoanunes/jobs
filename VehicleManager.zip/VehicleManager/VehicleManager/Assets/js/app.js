'use strict';

var webApp = angular.module('VM', ['ui.bootstrap', 'ui.router', 'ngCookies', 'angular-growl', 'ui.utils.masks', 'ngTable', 'ngSanitize', 'mwl.confirm'])
    .config(['$stateProvider', '$urlRouterProvider', function ($stateProvider, $urlRouterProvider) {
        // Para rotas não definidas.
        $urlRouterProvider.otherwise('/');

        // Rotas da aplicação.
        $stateProvider
            .state('start', {
                url: '/',
                templateUrl: 'Assets/views/start.html',
                controller: 'StartCtrl'
            })
            .state('vehicles/search', {
                url: '/vehicles/search',
                templateUrl: 'Assets/views/vehicle/search.html',
                controller: 'SearchVehicleCtrl'
            })
            .state('vehicles/register', {
                url: '/vehicles/register/{id}',
                templateUrl: 'Assets/views/vehicle/register.html',
                controller: 'RegisterVehicleCtrl'
            });
    }])
    .run(function ($rootScope, $filter, vmServices, alertsManager) {
        // Rota a ser exibida no breadcrumb da index.
        $rootScope.currentPage = {
            name: '',
            route: '',
            action: ''
        };

        // Seta novas rotas para exibir no breadcrumb da index.
        $rootScope.setCurrentPage = function (name, route, action) {
            $rootScope.currentPage = {
                name: name,
                route: route,
                action: action
            };
        };

        // Valida campos do formulário.
        $rootScope.isValidForm = function (form) {
            if (!form.$valid) {
                alertsManager.addError('Erro na validação. Verifique os campos em destaque.');
                form.$setSubmitted();
                form.$dirty = true;
                return false;
            }

            return true;
        };

        // Converte os valor(es) do(s) campo(s) informado(s) de um objeto ou lita de objetos para o tipo string.
        $rootScope.parseFieldsToString = function (data, fields) {
            if (!Array.isArray(data) && !Array.isArray(fields)) {
                data[fields] = String(data[fields]);
            } else if (!Array.isArray(data) && fields == undefined) {
                angular.forEach(Object.keys(data), function (f) {
                    data[f] = String(data[f]);
                });
            } else if (Array.isArray(data) && fields == undefined) {
                angular.forEach(data, function (d) {
                    angular.forEach(Object.keys(data), function (f) {
                        d[f] = String(d[f]);
                    });
                });
            } else if (Array.isArray(data) && !Array.isArray(fields)) {
                angular.forEach(data, function (d) {
                    d[fields] = String(d[fields]);
                });
            } else if (!Array.isArray(data) && Array.isArray(fields)) {
                angular.forEach(fields, function (f) {
                    data[f] = String(data[f]);
                });
            } else if (Array.isArray(data) && Array.isArray(fields)) {
                angular.forEach(data, function (d) {
                    angular.forEach(fields, function (f) {
                        d[f] = String(d[f]);
                    });
                });
            }

            return data;
        };
    })
    .factory('alertsManager', function ($interval, $filter, growl, growlMessages) {
        var timeOutError = 10000;
        var timeOutSuccess = 8000;
        var timeOutWarning = 8000;
        var timeOutInfo = 10000;
        var alertsManager = {};

        alertsManager.alerts = [];

        alertsManager.addError = function (message) {
            growl.error(message, {
                ttl: timeOutError
            });
        }

        alertsManager.addFixedError = function (message) {
            growl.error(message);
        }

        alertsManager.addSuccess = function (message) {
            growl.success(message, {
                ttl: timeOutSuccess
            });
        }

        alertsManager.addInfo = function (message) {
            growl.info(message, {
                ttl: timeOutInfo
            });
        }

        alertsManager.addWarning = function (message) {
            growl.warning(message, {
                ttl: timeOutWarning
            });
        }

        return alertsManager;
    })
    .filter('unique', function () {
        return function (collection, keyname) {
            var output = [],
                keys = [];

            angular.forEach(collection, function (item) {
                var key = item[keyname];

                if (keys.indexOf(key) === -1) {
                    keys.push(key);
                    output.push(item);
                }
            });

            return output;
        };
    });
