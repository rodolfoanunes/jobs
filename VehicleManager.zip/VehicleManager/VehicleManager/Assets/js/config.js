// Servidor e path do sistema.
var config = {
    serverVM: 'http://localhost:51343/api/'
};
