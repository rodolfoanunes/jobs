'use strict';

webApp.factory('vmServices', ['$http', '$rootScope', '$location', 'alertsManager', function ($http, $rootScope, $location, alertsManager) {
    var totalLoading = 0,
        init = function () {
            $('#loading').show();
            totalLoading++;
        },
        end = function () {
            totalLoading--;
            if (totalLoading <= 0) {
                $('#loading').hide();
            }
        },
        getHeaders = function () {
            return {
                headers: {}
            };
        },
        http_success = function (response, callback) {
            callback(response.data, response.status, response.headers, response.config);
        },
        http_fail = function (response, callback) {
            if (callback) {
                callback(response.data, response.status, response.headers, response.config);
            } else {
                switch (response.status) {
                    case -1:
                        alertsManager.addFixedError('Servidor fora do ar!');
                        console.log(response);

                        break;
                    case 401:
                        sessionStorage.setItem('AcessoNegado', '401: Unauthorized.')
                        $rootScope.loginRedirect();

                        break;
                    case 900:
                        alertsManager.addFixedError(response.data.Message);
                        console.log(response);

                        break;
                    default:
                        var msg = 'Ocorreu um erro na requisição';
                        msg += response.data && response.data.ExceptionMessage ? ': ' + response.data.ExceptionMessage : '!';
                        msg += response.data && response.data.Message ? ': ' + response.data.Message : '!';
                        alertsManager.addFixedError(msg);
                        console.log(response);
                }
            }
        };

    return {
        get: function (route, callback, errorCallback) {
            init();
            $http.get(config.serverVM + route, getHeaders())
                .then(function (response) {
                    http_success(response, callback);
                }, function (response) {
                    http_fail(response, errorCallback);
                })
                .finally(end);
        },
        post: function (route, model, callback, errorCallback) {
            init();
            $http.post(config.serverVM + route, model, getHeaders())
                .then(function (response) {
                    http_success(response, callback);
                }, function (response) {
                    http_fail(response, errorCallback);
                })
                .finally(end);
        },
        put: function (route, model, callback, errorCallback) {
            init();
            $http.put(config.serverVM + route, model, getHeaders())
                .then(function (response) {
                    http_success(response, callback);
                }, function (response) {
                    http_fail(response, errorCallback);
                })
                .finally(end);
        },
        delete: function (route, callback, errorCallback) {
            init();
            $http.delete(config.serverVM + route, getHeaders())
                .then(function (response) {
                    http_success(response, callback);
                }, function (response) {
                    http_fail(response, errorCallback);
                })
                .finally(end);
        }
    }
}]);
