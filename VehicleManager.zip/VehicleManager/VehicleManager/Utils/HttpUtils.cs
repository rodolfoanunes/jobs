﻿using System;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Results;

namespace VehicleManager.Utils
{
    public class HttpUtils
    {
        public static IHttpActionResult RetornaErroServidor(string msg)
        {
            HttpRequestMessage Request = new HttpRequestMessage();
            return new ResponseMessageResult(Request.CreateErrorResponse((HttpStatusCode)900, msg));
        }

        public static IHttpActionResult RetornaErroServidor(Exception ex)
        {
            HttpRequestMessage Request = new HttpRequestMessage();
            return new ResponseMessageResult(Request.CreateErrorResponse((HttpStatusCode)900, ex.Message));
        }
    }
}