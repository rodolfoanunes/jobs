﻿using System;
using System.ComponentModel.DataAnnotations;

namespace VehicleManager.Models
{
    public class Vehicle
    {
        public int Id { get; set; }

        [Required, MaxLength(40)]
        public string Mark { get; set; }

        [Required, MaxLength(50)]
        public string Model { get; set; }

        [Required, MaxLength(30)]
        public string Color { get; set; }

        [Required, Range(0, int.MaxValue)]
        public int Year { get; set; }

        [Required, Range(0.0, Double.MaxValue)]
        public decimal Price { get; set; }

        [MaxLength(1000)]
        public string Description { get; set; }

        [Required]
        public bool IsNew { get; set; }

        [Required]
        public DateTime DateCreation { get; set; }

        public DateTime? DateUpdate { get; set; }
    }
}