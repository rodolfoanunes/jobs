using System.Data.Entity.Migrations;

namespace VehicleManager.Migrations
{
    internal sealed class Configuration : DbMigrationsConfiguration<VehicleManager.App_Data.VehicleManagerContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = true;
            AutomaticMigrationsEnabled = true;
            ContextKey = "VehicleManager.App_Data.VehicleManagerContext";
        }

        protected override void Seed(VehicleManager.App_Data.VehicleManagerContext context)
        {
            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method 
            //  to avoid creating duplicate seed data.
        }
    }
}
