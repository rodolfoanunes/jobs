﻿using System.Data.Entity;
using VehicleManager.Models;

namespace VehicleManager.App_Data
{
    public class VehicleManagerContext : DbContext
    {
        public VehicleManagerContext() : base("VehicleManagerDB")
        {
            Database.SetInitializer(new MigrateDatabaseToLatestVersion<VehicleManagerContext, VehicleManager.Migrations.Configuration>());
        }

        public DbSet<Vehicle> Vehicles { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }
    }
}