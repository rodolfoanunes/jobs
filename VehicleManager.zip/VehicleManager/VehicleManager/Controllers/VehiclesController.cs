﻿using System;
using System.Data.Entity;
using System.Linq;
using System.Web.Http;
using VehicleManager.App_Data;
using VehicleManager.Models;
using VehicleManager.Utils;

namespace VehicleManager.Controllers
{
    public class VehiclesController : ApiController
    {
        VehicleManagerContext db = new VehicleManagerContext();

        [Route("api/vehiclesController/vehicles")]
        [HttpGet]
        public IHttpActionResult GetVehicles()
        {
            try
            {
                return Ok(db.Vehicles.ToList());
            }
            catch (Exception ex)
            {
                return HttpUtils.RetornaErroServidor("Erro ao buscar veículos: " + ex.Message);
            }
        }

        [Route("api/vehiclesController/vehicle/{id}")]
        [HttpGet]
        public IHttpActionResult GetVehicle(int id)
        {
            try
            {
                return Ok(db.Vehicles.Find(id));
            }
            catch (Exception ex)
            {
                return HttpUtils.RetornaErroServidor("Erro ao buscar veículo: " + ex.Message);
            }
        }

        [Route("api/vehiclesController/vehicle/insert")]
        [HttpPost]
        public IHttpActionResult PostVehicle(Vehicle vehicle)
        {
            try
            {
                vehicle.DateCreation = DateTime.Now;

                db.Vehicles.Add(vehicle);
                db.SaveChanges();

                return Ok();
            }
            catch (Exception ex)
            {
                return HttpUtils.RetornaErroServidor("Erro ao inserir veículo: " + ex.Message);
            }
        }

        [Route("api/vehiclesController/vehicle/update")]
        [HttpPut]
        public IHttpActionResult PutVehicle(Vehicle vehicle)
        {
            try
            {
                vehicle.DateUpdate = DateTime.Now;

                db.Entry(vehicle).State = EntityState.Modified;
                db.SaveChanges();

                return Ok();
            }
            catch (Exception ex)
            {
                return HttpUtils.RetornaErroServidor("Erro ao editar veículo: " + ex.Message);
            }
        }

        [Route("api/vehiclesController/vehicle/{id}/delete")]
        [HttpDelete]
        public IHttpActionResult DeleteVehicle(int id)
        {
            try
            {
                Vehicle vehicle = db.Vehicles.Find(id);

                if (vehicle == null)
                    return HttpUtils.RetornaErroServidor("Erro: veículo não encontrado para exclusão.");

                db.Entry(vehicle).State = EntityState.Deleted;
                db.SaveChanges();

                return Ok();
            }
            catch (Exception ex)
            {
                return HttpUtils.RetornaErroServidor("Erro ao deletar veículo: " + ex.Message);
            }
        }
    }
}